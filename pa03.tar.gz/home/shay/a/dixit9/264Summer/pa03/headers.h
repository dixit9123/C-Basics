#ifndef Pete
#define Pete
bool getLine(FILE*, char[]);
int check_validity(char[], int*);
char* changePath(int*, char*, FILE*);

#endif
